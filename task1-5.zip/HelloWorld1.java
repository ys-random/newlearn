/*1. 编程题 提示用户输入年月日信息，判断这一天是这一年中的第几天并打印。 

2. 编程题 编程找出 1000 以内的所有完数并打印出来。 所谓完数就是一个数恰好等于它的因子之和，如：6=1＋2＋3

3. 编程题 实现双色球抽奖游戏中奖号码的生成，中奖号码由 6 个红球号码和 1 个蓝球号码组成。 其中红球号码要求随机生成 6 个 1~33 之间不重复的随机号码。 其中蓝球号码要求随机生成 1 个 1~16 之间的随机号码。 

4. 编程题 自定义数组扩容规则，当已存储元素数量达到总容量的 80%时，扩容 1.5 倍。 例如，总容量是 10，当输入第 8 个元素时，数组进行扩容，容量从 10 变 15。

5. 编程题 使用二维数组和循环实现五子棋游戏棋盘的绘制，具体如下：*/
import java.util.Scanner;

public class HelloWorld1/*类名*/ {/*类体*/

    public static void main/*主方法名，程序的入口*/(String[] args) {/*主方法体*/
	
         //声明三个变量分别代表年月日
		//int year;
		//int month;
		//int day;
		//提示用户输入年月日信息
		System.out.println("请输入年");
		//创建扫描器记录用户输入的信息
		Scanner sc1= new Scanner(System.in);
		//放入变量年月日
		int year = sc1.nextInt();
        System.out.println("请输入月");
		Scanner sc2= new Scanner(System.in);
		int month = sc2.nextInt();
		System.out.println("请输入日");
		Scanner sc3= new Scanner(System.in);
        int day = sc3.nextInt();
		//打印输入的年月日
        System.out.println(year+"年"+month+"月"+day+"日");
		//声明12个月的数组，并初始化二月天数为28天
		int [] arr1 ={0,31,28,31,30,31,30,31,31,30,30,31};
		//初始化，根据月份循环累加数组
		int num=0;
        for(int i=0;i<month;i++){
			 num+= arr1[i];
			 
			 //System.out.println(i);
		}
		//当年份为闰年且大于二月时总天数加1 否则不加
		if(year%4==0&&month>2){
		      System.out.println("这一天是这一年的第"+(day+num+1)+"天");
			  }  else {
			  System.out.println("这一天是这一年的第"+(day+num)+"天"); 
		  }		
			
		
			
	}
} 