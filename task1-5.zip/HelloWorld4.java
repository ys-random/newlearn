/*1. 编程题 提示用户输入年月日信息，判断这一天是这一年中的第几天并打印。 

2. 编程题 编程找出 1000 以内的所有完数并打印出来。 所谓完数就是一个数恰好等于它的因子之和，如：6=1＋2＋3

3. 编程题 实现双色球抽奖游戏中奖号码的生成，中奖号码由 6 个红球号码和 1 个蓝球号码组成。 其中红球号码要求随机生成 6 个 1~33 之间不重复的随机号码。 其中蓝球号码要求随机生成 1 个 1~16 之间的随机号码。 

4. 编程题 自定义数组扩容规则，当已存储元素数量达到总容量的 80%时，扩容 1.5 倍。 例如，总容量是 10，当输入第 8 个元素时，数组进行扩容，容量从 10 变 15。

5. 编程题 使用二维数组和循环实现五子棋游戏棋盘的绘制，具体如下：*/
import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;

public class HelloWorld4/*类名*/ {/*类体*/

    public static void main/*主方法名，程序的入口*/(String[] args) {/*主方法体*/
	    
        System.out.println("请输入初始化数组长度");
         Scanner sc1= new Scanner(System.in);
         int a = sc1.nextInt();		 
	    System.out.println("请输入插入数组个数");
		 Scanner sc2= new Scanner(System.in);
		 int b = sc1.nextInt();
		 //创建长度为a的数组
		 int[] arr1 =new int[a];
		//创建扫描器记录用户输入的信息,暂不考虑b>a
         //赋值arr1
		 for(int i=0;i<b;i++){
			 arr1[i]=(int)(Math.random()*34);
			}
        
		System.out.println("数组数据A"+Arrays.toString(arr1));
		System.out.println("当前数组长度A"+arr1.length);	
		
		//如果达到总容量的 80% 扩容 1.5 倍创建新的数组
		if(b>=(int)(arr1.length*0.8)){
			int c=(int)(1.5*a);
			int[] arr2 =new int[c];
			for(int i=0;i<b;i++){
			 System.arraycopy(arr1,0,arr2,0,b);
			}
		System.out.println("数组数据B"+Arrays.toString(arr2));
		System.out.println("当前数组长度B"+arr2.length);	
		}
		
		
		
	}
} 