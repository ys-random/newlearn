/*1. 编程题 提示用户输入年月日信息，判断这一天是这一年中的第几天并打印。 

2. 编程题 编程找出 1000 以内的所有完数并打印出来。 所谓完数就是一个数恰好等于它的因子之和，如：6=1＋2＋3

3. 编程题 实现双色球抽奖游戏中奖号码的生成，中奖号码由 6 个红球号码和 1 个蓝球号码组成。 其中红球号码要求随机生成 6 个 1~33 之间不重复的随机号码。 其中蓝球号码要求随机生成 1 个 1~16 之间的随机号码。 

4. 编程题 自定义数组扩容规则，当已存储元素数量达到总容量的 80%时，扩容 1.5 倍。 例如，总容量是 10，当输入第 8 个元素时，数组进行扩容，容量从 10 变 15。

5. 编程题 使用二维数组和循环实现五子棋游戏棋盘的绘制，具体如下：*/
import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;

public class HelloWorld3/*类名*/ {/*类体*/

    public static void main/*主方法名，程序的入口*/(String[] args) {/*主方法体*/
	
         
		 int[] arr1 =new int[6];
		 int[] arr2 =new int[1]; 
 
		 //Arrays.fill(arr1,(int)(Math.random()*34))
		 arr2[0]=(int)(Math.random()*17);
		 for(int i=0;i<arr1.length;i++){
			 arr1[i]=(int)(Math.random()*34);
			 //System.out.println("红球号码"+(arr1[i])); 
		}
		 	
		System.out.println("红球号码"+Arrays.toString(arr1)+"蓝球号码"+Arrays.toString(arr2));
			
	}
} 